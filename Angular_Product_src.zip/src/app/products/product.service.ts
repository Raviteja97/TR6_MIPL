
import { Injectable } from "../../../node_modules/@angular/core";
import { IProduct } from "./product";
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from "../../../node_modules/rxjs/Observable";
import 'rxjs/add/operator/catch'
import 'rxjs/add/operator/do'


@Injectable()
export class ProductService{
private _productUrl ='./api/products/products.json';
constructor(private _http:HttpClient){}
getProducts(): Observable<IProduct[]>{
return this._http.get<IProduct[]>(this._productUrl).do(data =>console.log('All: '+ JSON.stringify(data))).catch(this.handleError);
}

private handleError(err: HttpErrorResponse){
console.error(err.message);
return Observable.throw(err.message);
}
/*getProducts(): IProduct[]{
return[{
"productId": 1,
"productName": "Leaf Rake",
"productCode": "GDN-0011",
"releaseDate": "March 19, 2016",
"description": "Leaf rake with 48-inch wooden handle.",
"price": 19.95,
"starRating": 3.2,
"imageUrl": "http://www.talentahead.com/img/Focus/CONSUMER-PRODUCTS.jpg"
},
{
"productId": 2,
"productName": "Garden Cart",
"productCode": "GDN-0023",
"releaseDate": "March 18, 2016",
"description": "15 gallon capacity rolling garden cart",
"price": 32.99,
"starRating": 4.2,
"imageUrl": "https://www.incimages.com/uploaded_files/image/970x450/products_364475.jpg"
},
{
"productId": 5,
"productName": "Hammer",
"productCode": "TBX-0048",
"releaseDate": "May 21, 2016",
"description": "Curved claw steel hammer",
"price": 8.9,
"starRating": 4.8,
"imageUrl": "https://img.deusm.com/informationweek/2014/09/1316005/apple_watch.png"
},
{
"productId": 8,
"productName": "Saw",
"productCode": "TBX-0022",
"releaseDate": "May 15, 2016",
"description": "15-inch steel blade hand saw",
"price": 11.55,
"starRating": 3.7,
"imageUrl": "https://amp.businessinsider.com/images/57f4036d9bd978d11b8b478f-750-375.jpg"
},
{
"productId": 10,
"productName": "Video Game Controller",
"productCode": "GMG-0042",
"releaseDate": "October 15, 2015",
"description": "Standard two-button video game controller",
"price": 35.95,
"starRating": 4.6,
"imageUrl": "https://www.lg.com/in/images/TV/features/signature-brand-productslink-d-type2.jpg"
}
];

}*/
} 
 
