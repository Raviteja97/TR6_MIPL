package org.flp.capbook.dao;

import java.util.List;

import org.flp.capbook.model.Sms;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("messageDao")
@Transactional
public interface IMessageDao extends JpaRepository<Sms,Integer> {

	@Query("select m from Sms m where m.mobileNumber=:mobileNum")
	List<Sms> getAllMessages(@Param("mobileNum") Long mobileNum);
	
	
	
	

}
