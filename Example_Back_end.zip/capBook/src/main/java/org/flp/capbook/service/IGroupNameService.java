package org.flp.capbook.service;

public interface IGroupNameService {

}
