package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.model.Message;

public interface IMsgService {

	List<Message> saveMessage(Message message);

	List<Message> getAllMessages();

	List<Message> getChatMessage(Integer user_id, Integer rec_id);

}
