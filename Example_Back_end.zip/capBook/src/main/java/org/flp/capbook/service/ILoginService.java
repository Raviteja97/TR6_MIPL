package org.flp.capbook.service;

import org.flp.capbook.model.Login;

public interface ILoginService {

	Boolean checkUser(Login login);
	
	

}
