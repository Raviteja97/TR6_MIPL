package org.flp.capbook.service;

import org.flp.capbook.model.UserProfile;


public interface IUserServiceGroups {

	UserProfile findGroupsuser(Integer input);

	

}
