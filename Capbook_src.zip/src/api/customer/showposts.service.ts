import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders,HttpRequest,HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";

import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { IShowPosts } from "../../app/showposts/Status";


const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class StatusService{
private uploadStatus='http://localhost:8088/saveStatus';

getStatusUrl:string='http://localhost:8088/getStatus';
showPosts=new IShowPosts();
deleteStatusUrl:string='http://localhost:8088/deleteStatus/';
constructor(private _http:HttpClient){
    
} 


p:string;
input:any;
userId:number=112; 



pushFileToStorage(status: IShowPosts): Observable<HttpEvent<IShowPosts>> {

    //const formdata: FormData = new FormData();
    
    //formdata.append('file', file);
   // alert(file);

    const req = new HttpRequest('POST', this.uploadStatus+"/"+this.userId,status, {
        responseType: 'text'
      });
  
      return this._http.request(req);
    }
  
  getStatus(userId:Number):Observable<IShowPosts[]>{
      console.log(userId)
this.getStatusUrl="http://localhost:8088/getStatus/"+userId;
    //const req = new HttpRequest('GET', this.getStatusUrl+"/"+userId)
      return this._http.get<[IShowPosts]>(this.getStatusUrl);
       // return this._http.request(req);
  }

  deleteStatus(status_id:Number){
    return this._http.delete(this.deleteStatusUrl+status_id);
  }
 
}
