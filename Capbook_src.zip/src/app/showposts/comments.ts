import { IShowPosts } from "./Status";

export class IComments{
    commentId:number;
	commentText:string;
	postedBy:number;
	postedTo:number;
	dateOfPosting:Date;
    status:IShowPosts;
}
