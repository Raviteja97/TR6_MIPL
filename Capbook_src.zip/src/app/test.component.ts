import { Component } from '@angular/core';

@Component({
  selector: 'test-root',
 // templateUrl: './test.component.html'
 template :"<div><h1>{{title}} and {{num1+num2}}</h1></div>"
  
})
export class TestComponent {
  title = 'Now This page does addition';
  num1=10;
  num2=20;
}
