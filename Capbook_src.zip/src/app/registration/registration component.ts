import { Component, OnInit } from "@angular/core";
import { ICustomer } from "../../api/customer/customer";
import { CustomerService } from "../../api/customer/customer.service";

@Component({
    selector:'reg-form',
    templateUrl:'./registration.component.html'
})
export class RegistrationComponent implements OnInit{
      butlabel:string='Register'
      flag:boolean=false
    customer:ICustomer=new ICustomer();
    constructor(private _customerService:CustomerService)
    {
       
    }
    onSubmit():void{
       
        if(this.flag)
        {
            this._customerService.editCustomers(this.customer).subscribe(customers=>console.log(customers))
        }
        else
        {
          alert(this.customer.firstName)
            this.createCustomers()
        }
    }
    createCustomers():void{
    this.butlabel='Register'
        console.log(JSON.stringify(this.customer))
      this._customerService.createCustomers(this.customer).subscribe(customer=>this.customer)
    } 
    ngOnInit():void{
       this.createCustomers()
    }




}