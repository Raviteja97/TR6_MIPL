import { Component, OnInit } from '@angular/core';
import { InviteService } from './invite.service';


@Component({
  selector: 'app-newuser',
  templateUrl: './newuser.component.html',
  styleUrls: ['./newuser.component.css']
})
export class NewuserComponent implements OnInit {

 displaysend: boolean= false;
  msg: string;

  constructor(private service: InviteService) {


  }

  ngOnInit() {
  }

  

  sendEmail(email) {
    alert(email);
    this.service.inviteUser(email).subscribe(data => { this.msg = data; console.log(data); })
   // alert(this.msg);
    location.reload();
  } 
  
  onSubmit(): void {
    this.displaysend=true;
  }
}
