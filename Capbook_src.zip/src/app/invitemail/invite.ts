export interface IInvite{
    email:String;
}