import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product/product-list.component';
import { ConvertToSpacesPipe } from './shared/convert-t0-spaces.pipe';
import { StarComponent } from './shared/star.component';

import {  HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './products/product-detail.component';
//import { TestComponent } from './test.component';
import { RouterModule, Routes} from '@angular/router'; 
//import {RouterModule} from '@angular/router'
import { WelcomeComponent } from './home/welcome.component';
import { CustomerComponent } from './customer/customer.component';
import { RegistrationComponent } from './registration/registration component';
import { ShowpostsComponent } from './showposts/showposts.component';
import { ProfilelistComponent } from './profile/profilelist/profilelist.component';
import { StatusService } from '../api/customer/showposts.service';
import { InviteService } from './invitemail/invite.service';
import { NewuserComponent } from './invitemail/newuser.component';
import { LikeCommentService } from './like-comment/like-comment.service';





/* const appRoutes: Routes = [
  
  { path: 'showposts', component: ShowpostsComponent },
  { path: 'home', redirectTo: '/', pathMatch: 'full' }
  
  ]; 
 */
@NgModule({
  declarations: [
  //TestComponent,AppComponent
 AppComponent,//ProductListComponent,ConvertToSpacesPipe,StarComponent,CustomerComponent, WelcomeComponent ,ProductDetailComponent,
 //RegistrationComponent,
 ShowpostsComponent,
 //MovieComponent
ProfilelistComponent,
NewuserComponent,



  ],
  imports: [
    
    BrowserModule,FormsModule,HttpClientModule//,UserProfile
    /* ,RouterModule.forRoot([//{path:'products',component:ProductListComponent},
   //{path :'products/:id' ,component:ProductDetailComponent},
   {path:'welcome',component:WelcomeComponent},
  {path : '',redirectTo:'welcome',pathMatch:'full'},
  {path :'**',redirectTo:'welcome',pathMatch:'full'},
  {
      path:'customer',component:CustomerComponent
   }
]) */

  ],
  providers: [StatusService,InviteService,LikeCommentService],
 // bootstrap: [MovieComponent]
  bootstrap: [AppComponent]
})
export class AppModule { }
