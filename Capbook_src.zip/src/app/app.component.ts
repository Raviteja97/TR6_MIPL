import { Component } from '@angular/core';
import { ProductService } from '../api/products/product.service';
import { CustomerService } from '../api/customer/customer.service';
import { StatusService } from '../api/customer/showposts.service';
import { LikeCommentService } from './like-comment/like-comment.service';

@Component({
  selector: 'pm-root',
   templateUrl: './app.component.html',
   //styleUrls: ['./app.component.css']
  /* template:`
 <div class='container-fluid'>
  <pm-showposts></pm-showposts>
  </div>   
  `  , */
  providers: [StatusService,LikeCommentService],
 // providers:[CustomerService]
})
export class AppComponent {
  // title = 'Angular: Getting Started';
  //pageTitle:string='Customers';
}
