export class Profile{
    fullName: string;
    photoPath: string;
    description: string;
    relationship: string;
    mobileNo: number;
    status:number;
}